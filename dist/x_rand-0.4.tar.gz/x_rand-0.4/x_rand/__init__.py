# For python 3
try:
    from x_rand.x_rand import x_rand, x_rand_admin
# For python 2
except:
    from x_rand import x_rand, x_rand_admin
