from x_rand.x_rand import x_rand, x_rand_admin
